# Evidencias del radar de credenciales Caso24

Experimento del 20 de noviembre de 2026. Las cifras se obtuvieron mediante ejecución local; no se han simulado resultados de entrenamiento o rendimiento. Los datos predictivos sí son sintéticos y su alcance se declara expresamente.

## Estructura

- `data/`: muestra derivada de 10 000 observaciones de PWLDS, procedencia, licencia, mapeo y configuración. No contiene cadenas de contraseña.
- `training/registry/`: arrays consolidados, grupos opacos, índices de las particiones y folds, registro de ensayos, predicciones y artefactos M1/M2/M3.
- `training/source_snapshot/`: fuentes exactas del entrenamiento, cuya huella coincide con el registro. El validador fue refactorizado después para compartirlo con la API de previsualización; esta instantánea conserva la versión utilizada en el experimento.
- `training/replay_result.json`: reproducción comprobada de la búsqueda y de las predicciones de los tres modelos.
- `performance/`: JMX definitivo, 500 vectores numéricos de entrada, JTL válidos de 5/15/25 usuarios, metadatos y resumen. No contiene tokens ni respuestas HTTP completas.
- `n8n/`: metadatos depurados de ejecuciones finales, diagnóstico de intentos excluidos y workflows portables con referencias de entorno. No son exportaciones de credenciales de la instancia.
- `software/`: instantánea de los archivos del proyecto modificados para esta entrega, sin configuraciones privadas ni dependencias instaladas.
- `figures/`: figuras científicas calculadas a partir del registro y de los JTL.
- `scripts/`: utilidades portables para repetir la búsqueda, volver a calcular estadísticas, obtener la fuente fijada y construir las figuras y el documento.
- `live_verification.json`: comprobación final de lectura de servicios, presencia del dataset y del experimento, auditoría y contenciones de prueba.
- `validation.json`: comprobaciones de software y sus límites.
- `SHA256SUMS.json`: integridad de los archivos distribuidos. No proporciona una firma de identidad de los autores.

## Reproducción exacta del entrenamiento

Utiliza Python 3.14.4 y las versiones de `requirements_training.txt`. En la laptop ya está preparado el entorno `backend/.venv` del proyecto original. No cargues artefactos joblib de otra procedencia sin una verificación de confianza.

```bash
RUTA_PYTHON="/ruta/al/proyecto/backend/.venv/bin/python"
RUTA_EVIDENCIAS="/ruta/al/directorio/extraido"
"$RUTA_PYTHON" "$RUTA_EVIDENCIAS/scripts/replay_experiment.py" "$RUTA_EVIDENCIAS" --output "$RUTA_EVIDENCIAS/replay_local.json"
```

Este script verifica hashes, independencia de grupos, los tres candidatos y tres folds por modelo, parámetros seleccionados, coincidencia exacta de predicciones y coincidencia con cada artefacto persistido. Se volvió a ejecutar satisfactoriamente sobre estas evidencias. No cambia el ganador M2 ni usa la prueba para volver a seleccionar.

No se deben regenerar los grupos y asumir que las particiones serán iguales. El importador usa una sal aleatoria de privacidad; los arrays y los índices archivados son la referencia para repetir este experimento exacto.

## Recalcular JMeter sin lanzar carga

```bash
python scripts/summarize_benchmark.py performance
```

Recalcula las estadísticas desde los JTL existentes. No consulta ninguna cuenta ni ejecuta contención. El JMX conserva únicamente propiedades para recibir la autorización; no tiene un token incrustado.

## Nueva prueba de carga local

Primero arranca el laboratorio con `scripts/start_course_lab.py` del proyecto original, PostgreSQL y n8n/Mailpit. Instala Apache JMeter 5.6.3 desde su fuente oficial y verifica el hash publicado. Luego ejecuta, con el Python del backend:

```bash
python scripts/run_benchmark.py --project /ruta/al/proyecto --evidence /ruta/a/evidencias --jmeter-home /ruta/apache-jmeter-5.6.3 --output /ruta/a/nuevos_resultados
```

La carpeta de salida debe ser nueva. La utilidad crea una identidad local temporal de auditor, pasa el token en memoria mediante un descriptor de archivo Linux, valida precondiciones y desactiva esa identidad al terminar. Necesita la configuración privada existente del proyecto y permiso para conectarse a su base local; no la distribuye. Los nuevos tiempos pueden diferir y no deben sobrescribir los registros del artículo. La prueba presupone el mismo ID de experimento instalado en el registro local y solo realiza lecturas e inferencia de previsualización.

## Volver a obtener la fuente pública

```bash
python scripts/fetch_pwlds.py --project /ruta/al/proyecto --output /ruta/a/muestra_nueva
```

Fija el commit de PWLDS indicado en el manifiesto y muestrea los mismos prefijos; no guarda cadenas raw. Requiere acceso a Internet. Una nueva importación y entrenamiento debe registrarse como otra ejecución, sin reemplazar el conjunto de prueba del artículo.

## Figuras y manuscrito

`python scripts/generate_article_figures.py /ruta/a/evidencias` recalcula las cuatro figuras con Matplotlib. Para reconstruir el DOCX usa `scripts/build_article.py /ruta/a/evidencias` con el runtime documental que tenga python-docx; el resultado se escribe en `rendered_article/`. Las fuentes y los saltos de página pueden variar entre procesadores: la entrega DOCX fue renderizada y revisada visualmente. Las imágenes de revisión y el PDF de control no forman parte del manuscrito distribuido.

## Interpretación

Los resultados de clasificación miden concordancia con etiquetas sintéticas de debilidad. No miden detección de ataques o probabilidad de compromiso. Los perfiles JMeter duran 20 s, llevan una pausa por petición y no determinan capacidad máxima. Las pruebas de n8n usan endpoints y correos locales; no validan todos los fallos externos ni el disparo automático de W12. No se debe presentar la exactitud histórica binaria como una comparación antes y después de la tarea multiclase actual.
